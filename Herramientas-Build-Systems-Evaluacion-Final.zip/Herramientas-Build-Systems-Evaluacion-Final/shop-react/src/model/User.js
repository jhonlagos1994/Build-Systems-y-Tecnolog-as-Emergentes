export default class User {

    username;
    token;
    
} 